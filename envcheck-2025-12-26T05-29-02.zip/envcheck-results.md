
# SAP Fiori tools - Environment Check

<br>

## Destination Details (1)

### Details for `simplecap-srv`
🚫 &nbsp; OData V2 catalog service not available.<br>
🚫 &nbsp; OData V4 catalog service not available.<br>
✅ &nbsp; The destination property: `HTML5.DynamicDestination` is set to `true`.<br>
🟡 &nbsp; Please ensure the property: `HTML5.Timeout` is set to a minimum value of `60000` in SAP Business Technology Platform Cockpit > 'Additional Properties'.<br>
✅ &nbsp; SAP Fiori tools usage: Configured to be used by SAP Fiori Generator as a partial URL.<br>
|Name|Description|Host|sap-client|Fiori tools usage|WebIDEUsage|WebIDEAdditionalData|Type|Authentication|ProxyType|HTML5.DynamicDestination|HTML5.Timeout|
|--|--|--|--|--|--|--|--|--|--|--|--|
|simplecap-srv||https://602b9a51trial-qa-simplecap-srv.cfapps.us10-001.hana.ondemand.com||Partial URL|odata_gen||HTTP|OAuth2UserTokenExchange|Internet|true||

<br>

## Messages (20)
🟢 &nbsp; Info: Platform: linux<br>
🟢 &nbsp; Info: Development environment: Business Application Studio<br>
🟢 &nbsp; Info: Business Application Studio dev space: Full Stack Cloud Application.<br>
🟢 &nbsp; Info: Cloud CLI tools: 8.7.4<br>
🟢 &nbsp; Info: Application Wizard: 1.20.2<br>
🟢 &nbsp; Info: SAP Fiori tools - SAP Fiori generator: 1.20.0.<br>
🟢 &nbsp; Info: SAP Fiori tools - Application Modeler: 1.20.0<br>
🟢 &nbsp; Info: SAP Fiori tools - Guided Development: 1.20.0<br>
🟢 &nbsp; Info: SAP Fiori tools - Service Modeler: 1.20.0<br>
🟢 &nbsp; Info: SAP Fiori tools - XML Annotation Language Server: 1.20.0<br>
🟢 &nbsp; Info: XML Toolkit: 1.2.1<br>
🟢 &nbsp; Info: SAP CDS Language Support: 9.4.0.<br>
🟢 &nbsp; Info: UI5 Language Assistant Support: 4.0.84<br>
🟢 &nbsp; Info: Versions: {
    "node": "22.13.1",
    "acorn": "8.14.0",
    "ada": "2.9.2",
    "amaro": "0.2.0",
    "ares": "1.34.4",
    "brotli": "1.1.0",
    "cjs_module_lexer": "1.4.1",
    "cldr": "46.0",
    "icu": "76.1",
    "llhttp": "9.2.1",
    "modules": "127",
    "napi": "9",
    "nbytes": "0.1.1",
    "ncrypto": "0.0.1",
    "nghttp2": "1.64.0",
    "nghttp3": "1.6.0",
    "ngtcp2": "1.9.1",
    "openssl": "3.0.15+quic",
    "simdjson": "3.10.1",
    "simdutf": "5.6.4",
    "sqlite": "3.47.2",
    "tz": "2024b",
    "undici": "6.21.1",
    "unicode": "16.0",
    "uv": "1.49.2",
    "uvwasi": "0.0.21",
    "v8": "12.4.254.21-node.22",
    "zlib": "1.3.0.1-motley-82a5fec"
}.<br>
🟢 &nbsp; Info: Found 9 destinations.<br>
🔴 &nbsp; Error: Cannot query v2 catalog service for simplecap-srv.<br>
<details><summary>ℹ Debug</summary>
<pre>
 Request to URL:  failed with message: e.catalog is not a function. Complete error object: {}
</pre></details>
🔴 &nbsp; Error: Cannot query v4 catalog service for simplecap-srv.<br>
<details><summary>ℹ Debug</summary>
<pre>
 Request to URL:  failed with message: e.catalog is not a function. Complete error object: {}
</pre></details>
🟡 &nbsp; Warning: Additional property `HTML5.Timeout` is missing from the destination: simplecap-srv. The suggested minimum value is '60000'.<br>

<br>

## All Destinations (9)
<details>
<summary>Show all destinations.</summary>

|Name|Description|Host|sap-client|Fiori tools usage|WebIDEUsage|WebIDEAdditionalData|Type|Authentication|ProxyType|HTML5.DynamicDestination|HTML5.Timeout|
|--|--|--|--|--|--|--|--|--|--|--|--|
|capstatic||https://602b9a51trial-dev-commonsapbtp.cfapps.us10-001.hana.ondemand.com/||Invalid URL|||HTTP|NoAuthentication|Internet|true||
|CICD-backend|CAP service destination|https://602b9a51trial-qa-cicd-capm-srv.cfapps.us10-001.hana.ondemand.com/||Invalid URL|custom||HTTP|NoAuthentication|Internet|true||
|libcap||https://602b9a51trial-qa-sapbtpcommon.cfapps.us10-001.hana.ondemand.com/||Invalid URL|||HTTP|NoAuthentication|Internet|true||
|mathbasics-library||https://mathbasics-library.cfapps.us10-001.hana.ondemand.com||Invalid URL|custom||HTTP|NoAuthentication|Internet|true||
|Northwind|Northwind OData services|https://services.odata.org||Catalog Service|odata_abap,dev_abap||HTTP|NoAuthentication|Internet|true||
|PMO_DEST||https://ba386046trial-dev-backend-srv.cfapps.us10-001.hana.ondemand.com/||Partial URL|odata_gen||HTTP|NoAuthentication|Internet|true||
|resource_management||https://602b9a51trial-qa-backend-srv.cfapps.us10-001.hana.ondemand.com/||Partial URL|odata_gen||HTTP|OAuth2UserTokenExchange|Internet|true||
|RMT_CAP|Cap service for resource management tool. |https://genpact-llc-genpact-sap-ba-studio-56v4fjiz-dev-glassboa458e90b8.cfapps.us10-001.hana.ondemand.com/||Partial URL|odata_gen||HTTP|NoAuthentication|Internet|true||
|simplecap-srv||https://602b9a51trial-qa-simplecap-srv.cfapps.us10-001.hana.ondemand.com||Partial URL|odata_gen||HTTP|OAuth2UserTokenExchange|Internet|true||

</details>

<br>

## Environment
Platform: `linux`<br>
Development environment: `Business Application Studio`<br>
Dev Space Type: `Full Stack Cloud Application`<br>
|Tools/Extensions|Version|
|--|--|
|Node.js|22.13.1|
|Cloud CLI tools|8.7.4|
|SAP Fiori tools - Fiori generator|1.20.0|
|Application Wizard|1.20.2|
|SAP Fiori tools - Application Modeler|1.20.0|
|SAP Fiori tools - Guided Development|1.20.0|
|SAP Fiori tools - Service Modeler|1.20.0|
|SAP Fiori tools - XML Annotation Language Server|1.20.0|
|XML Toolkit|1.2.1|
|SAP CDS Language Support|9.4.0|
|UI5 Language Assistant Support|4.0.84|
<details><summary>Versions</summary>
<pre>
{
    "node": "22.13.1",
    "acorn": "8.14.0",
    "ada": "2.9.2",
    "amaro": "0.2.0",
    "ares": "1.34.4",
    "brotli": "1.1.0",
    "cjs_module_lexer": "1.4.1",
    "cldr": "46.0",
    "icu": "76.1",
    "llhttp": "9.2.1",
    "modules": "127",
    "napi": "9",
    "nbytes": "0.1.1",
    "ncrypto": "0.0.1",
    "nghttp2": "1.64.0",
    "nghttp3": "1.6.0",
    "ngtcp2": "1.9.1",
    "openssl": "3.0.15+quic",
    "simdjson": "3.10.1",
    "simdutf": "5.6.4",
    "sqlite": "3.47.2",
    "tz": "2024b",
    "undici": "6.21.1",
    "unicode": "16.0",
    "uv": "1.49.2",
    "uvwasi": "0.0.21",
    "v8": "12.4.254.21-node.22",
    "zlib": "1.3.0.1-motley-82a5fec"
}
</pre></details>

<sub>created at 2025-12-26 05:29:11 (UTC)</sub>
